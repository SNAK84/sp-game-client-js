#!/usr/bin/env python3
"""Build SP-Game technology 136 localized effects from ONE immutable source PNG.

Only the plasma window, three extractor beams, illuminated ore and conveyor guide
are modified. Never regenerate the station, scenery, camera, or ship silhouettes.
"""
from __future__ import annotations
import math
import json
import pathlib
import subprocess
import zipfile
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

SOURCE = pathlib.Path('/mnt/data/космический_комплекс_добычи_кристаллов.png')
OUT = pathlib.Path('/mnt/data/spg_tech_136')
OUT.mkdir(exist_ok=True)
SIZE = 360
NFRAMES = 48
MS = 40
original = Image.open(SOURCE).convert('RGB')
SW, SH = original.size
SCALE = SIZE / SW
base_img = original.resize((SIZE, SIZE), Image.Resampling.LANCZOS)
base = np.asarray(base_img, dtype=np.float32)
ygrid, xgrid = np.mgrid[:SIZE, :SIZE]


def pt(x, y):
    return (round(x * SCALE), round(y * SCALE))


def region_polygon(points, soften=0.6):
    im = Image.new('L', (SIZE, SIZE))
    d = ImageDraw.Draw(im)
    d.polygon([pt(*p) for p in points], fill=255)
    if soften:
        im = im.filter(ImageFilter.GaussianBlur(soften))
    return np.asarray(im, dtype=np.float32) / 255.0


# Hard constraints: these masks do not move or expand during the animation.
reactor_mask = region_polygon([(535,355),(717,355),(719,551),(528,551)], 1.0)
processing_mask = region_polygon([(905,505),(1177,505),(1177,664),(906,664)], 0.8)
conveyor_mask = region_polygon([(282,850),(419,833),(510,855),(673,833),(790,812),(899,783),(1045,754),
                                 (1079,802),(1042,882),(913,919),(708,936),(493,967),(294,971),(281,924)], 0.8)
drill_mask = region_polygon([(0,668),(135,653),(141,776),(0,820)], 1.0)

# The tint detector confines most changes to pixels already glowing cyan, rather
# than adding a generic wash over metallic details and the immutable star field.
r = base[:,:,0]; g=base[:,:,1]; b=base[:,:,2]
cyan = np.clip((b-r-3) / 64, 0,1) * np.clip((g-r-3) / 48,0,1) * np.clip((b-67)/100,0,1)

# White/blue plasma also has nearly white highlights. Require proximity to the
# inside of the narrow reactor itself, even if a pixel is very bright.


def gaussian(cx,cy,sx,sy):
    cx, cy = cx*SCALE,cy*SCALE
    return np.exp(-.5*((xgrid-cx)/(sx*SCALE))**2 - .5*((ygrid-cy)/(sy*SCALE))**2)


def rgb_layer(cyan_amount, warm_amount=None):
    if warm_amount is None:
        warm_amount = np.zeros_like(cyan_amount)
    return np.stack((cyan_amount*0.37+warm_amount*1.0,
                     cyan_amount*0.80+warm_amount*0.38,
                     cyan_amount*1.0+warm_amount*0.13), axis=-1)


# Fixed physical positions of the existing three laser columns, in source px.
beam_positions = [947, 1030, 1129]
beam_window = [(500,625),(500,625),(500,622)]

# Localized guide LEDs along the original curved conveyor, not animated ore
# geometry. The track exactly follows the cyan light strip under the cargo.
track = [(285,956),(345,950),(465,946),(590,936),(715,917),(850,902),(950,879),(1009,850),(1041,799)]
segments = []
for a,bp in zip(track[:-1],track[1:]):
    segments.append(math.dist(a,bp))
length = sum(segments)


def along_track(u):
    target = (u%1.0)*length
    for i,seglen in enumerate(segments):
        if target <= seglen:
            t = target/seglen
            a,bp = track[i:i+2]
            return a[0]+(bp[0]-a[0])*t, a[1]+(bp[1]-a[1])*t
        target -= seglen
    return track[-1]


# Palette is shared with every frame; static pixels decode byte-identically.
base120 = original.resize((120,120), Image.Resampling.LANCZOS)
palette = base120.quantize(colors=256, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
frames360=[]
frames120=[]

for k in range(NFRAMES):
    phase = k/NFRAMES
    rad = 2*math.pi*phase

    # Reactor: a few fast highlights travelling UP along the unchanged luminous
    # spiral. Sidewalls and window structure have no movement at all.
    reactor = np.zeros((SIZE,SIZE), dtype=np.float32)
    for offset, strength in [(0.0,90),(.37,47),(.73,32)]:
        u = (phase+offset)%1.0
        yy = 548 - 185*u
        xx = 624 + 29*math.sin((yy-350)*0.047+0.6)
        reactor += strength * gaussian(xx, yy, 19, 12)
        reactor += strength*0.38*gaussian(xx, yy, 40, 27)
    # Only existing plasma highlights breathe with the animated pulses.
    vertical_rhythm = .5+.5*np.sin(rad*2.0 + ygrid*.075)
    reactor += 34 * cyan * vertical_rhythm
    reactor *= reactor_mask

    # Three extraction beams: the underlying vertical cyan shafts are static.
    # A brighter short hotspot travels down each shaft, staggered by phase.
    processing = np.zeros((SIZE,SIZE),dtype=np.float32)
    for j,x0 in enumerate(beam_positions):
        beamphase = (phase + (j*.23))%1.0
        y0 = 508 + 106 * beamphase
        # Confine glow within ±17 source pixels from each shaft, upper chamber.
        narrow = np.exp(-.5*((xgrid-x0*SCALE)/(11*SCALE))**2)
        hot = np.exp(-.5*((ygrid-y0*SCALE)/(19*SCALE))**2)
        processing += 92*narrow*hot
        processing += 31*narrow*np.exp(-.5*((ygrid-y0*SCALE)/(48*SCALE))**2)
    # Make the ore in the right processing window twinkle gently, not relocate.
    processing += 20*cyan*(.5+.5*np.sin(rad*2.0+xgrid*.10-ygrid*.07))
    processing *= processing_mask

    # Conveyor: three travelling narrow glints along the already illuminated
    # guide strip, plus crystalline faceting variations in a fixed location.
    conveyor = np.zeros((SIZE,SIZE),dtype=np.float32)
    for offset,strength in ((0,75),(.33,62),(.67,72)):
        xx,yy=along_track(phase+offset)
        conveyor += strength * gaussian(xx, yy, 16, 10)
        conveyor += strength*.22*gaussian(xx, yy, 28, 15)
    conveyor += 24*cyan*(.5+.5*np.sin(rad*1.7-xgrid*.085+ygrid*.055))
    conveyor *= conveyor_mask

    # Small, localized flicker at the tip of the drill only.
    drill = (35+21*math.sin(rad*3.0)**2)*gaussian(56,707,37,32)*drill_mask*cyan

    # Weighted additive emission, clipped by each region's immutable mask.
    glow = reactor + processing + conveyor + drill
    composed = np.clip(base + rgb_layer(glow), 0, 255).astype(np.uint8)
    img360=Image.fromarray(composed,'RGB')
    frames360.append(img360)
    frames120.append(img360.resize((120,120),Image.Resampling.LANCZOS).quantize(
                  palette=palette,dither=Image.Dither.NONE))

# The first frame has the same background and model geometry as all other frames.
# GIF uses a single palette and no accidental new pixels outside masks.
gifpath=OUT/'extraterrestrial_mining_136.gif'
frames120[0].save(gifpath,save_all=True,append_images=frames120[1:],duration=MS,
                 loop=0,optimize=False,disposal=2)
# Static source + compact static base (without effects).
original.save(OUT/'extraterrestrial_mining_136_source.png', optimize=True)
base120.save(OUT/'extraterrestrial_mining_136_static.png', optimize=True)

# Larger animation for inspecting the localized light motion.
webp = OUT/'extraterrestrial_mining_136.webp'
frames240=[im.resize((240,240),Image.Resampling.LANCZOS) for im in frames360]
frames240[0].save(webp,save_all=True,append_images=frames240[1:],duration=MS,
                  loop=0,format='WEBP',quality=86,method=5)

# A true MP4 is included for viewers that display only the first GIF frame.
with tempfile.TemporaryDirectory(prefix='spg136_') as tmpdir:
    tmp=pathlib.Path(tmpdir)
    for k,im in enumerate(frames360):
        im.resize((480,480),Image.Resampling.LANCZOS).save(tmp/f'{k:03d}.png')
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','25',
                    '-stream_loop','2','-i',str(tmp/'%03d.png'), '-c:v','libx264',
                    '-pix_fmt','yuv420p','-crf','19','-movflags','+faststart',
                    str(OUT/'extraterrestrial_mining_136_preview.mp4')],check=True)

# Storyboard: 8 *actual decoded GIF frames*, not newly-generated illustrations.
check=Image.open(gifpath)
indices=[0,6,12,18,24,30,36,42]
contact=Image.new('RGB',(4*240,2*267),(17,21,27))
d = ImageDraw.Draw(contact)
for i,ind in enumerate(indices):
    check.seek(ind)
    fr=check.convert('RGB').resize((240,240),Image.Resampling.NEAREST)
    x,y=i%4*240, i//4*267
    contact.paste(fr,(x,y))
    d.text((x+8,y+245),f'Кадр {ind+1:02d}',fill=(230,230,240))
contact.save(OUT/'actual_gif_frames.png', optimize=True)

# Render the maximal area in which anything CAN move. Check invariant per
# decoded GIF frames, not just original RGB working frames.
allowed = np.maximum.reduce((reactor_mask,processing_mask,conveyor_mask,drill_mask))
allow120 = (Image.fromarray(np.uint8(allowed*255),'L')
            .resize((120,120),Image.Resampling.BILINEAR))
allowed_bool = np.asarray(allow120)>0
# Some GIF blocks expand due to sharpening/resize; expand 2 px around allowed.
from PIL import ImageFilter
allowed_bool=np.asarray(allow120.filter(ImageFilter.MaxFilter(7)))>0
mask_save=Image.fromarray(np.where(allowed_bool,255,0).astype(np.uint8),'L')
mask_save.save(OUT/'allowed_animation_zones.png')
first=Image.open(gifpath)
static_array=np.array(first.convert('RGB'))
error=0
unique_frames=set()
for i in range(first.n_frames):
    first.seek(i)
    arr=np.asarray(first.convert('RGB'))
    error=max(error,int(np.max(np.abs(arr.astype(np.int16)-static_array.astype(np.int16))[~allowed_bool])))
    unique_frames.add(arr.tobytes())
assert error==0, 'Static region was modified outside explicitly permitted masks'
assert len(unique_frames)==NFRAMES, f'Not all frames differ: {len(unique_frames)}/{NFRAMES}'
mask_area = round(allowed_bool.mean()*100,1)
meta={'source':SOURCE.name,'id':136,'frames':NFRAMES,'frame_duration_ms':MS,
      'cycle_seconds':NFRAMES*MS/1000,'gif_size':[120,120], 'webp_size':[240,240],
      'immutable_background_verified': True, 'max_outside_mask_rgb_difference':error,
      'distinct_decoded_gif_frames':len(unique_frames),
      'allowed_change_region_percent':mask_area,
      'effect_zones':['reactor internal plasma pulses','three extraction beam highlights',
                      'conveyor guide lights and crystal shimmer','small drill tip flicker']}
(OUT/'verification.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False))

archive=pathlib.Path('/mnt/data/spg_tech_136_animated.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(OUT.iterdir()):
        z.write(p,p.name)
    z.write(__file__,'build_tech_136.py')
print(json.dumps(meta, ensure_ascii=False, indent=2))
for p in sorted(OUT.iterdir()): print(p.name,round(p.stat().st_size/1024),'KiB')
print('ZIP',archive,round(archive.stat().st_size/1024),'KiB')
