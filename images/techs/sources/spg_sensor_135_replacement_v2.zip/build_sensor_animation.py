#!/usr/bin/env python3
"""Create a fixed-geometry localized emission animation from one static illustration.
No regeneration of the antenna or background. Requires Pillow and NumPy.
"""
from pathlib import Path
import math, numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops, ImageFont

OUT = Path(__file__).resolve().parent
SOURCE = OUT / 'sensor_tech_135.png'
NFRAMES, FRAME_MS = 48, 40
S = 4
W = H = 120
# Optical overlay: gentle perimeter glints, multiple small travelling wave packets.
RINGS = [
 (61.7, 14.6, 32.2, 9.8, 0),
 (61.7, 27.9, 25.2, 8.7, 22),
 (61.7, 40.8, 18.4, 6.7, 43),
 (61.7, 51.6, 12.1, 4.7, 65),
 (61.7, 61.0, 7.0, 2.7, 86),
]
base = Image.open(SOURCE).convert('RGB').resize((W, H), Image.Resampling.LANCZOS)
base_array = np.asarray(base, dtype=np.float32)

def draw_ellipse_arc(draw, cx, cy, rx, ry, deg_start, span, color, width):
    pts=[]
    for step in range(55):
        a=math.radians(deg_start + step/54*span)
        pts.append((int((cx+rx*math.cos(a))*S),int((cy+ry*math.sin(a))*S)))
    draw.line(pts, fill=color, width=width, joint='curve')
    x,y=pts[-1]; draw.ellipse((x-2,y-2,x+2,y+2),fill=color)

frames_rgb=[]
for i in range(NFRAMES):
    t=i/NFRAMES
    rim_glow=Image.new('L',(W*S,H*S),0)
    rim_core=Image.new('L',(W*S,H*S),0)
    beam_glow=Image.new('L',(W*S,H*S),0)
    beam_core=Image.new('L',(W*S,H*S),0)
    rg,rc=ImageDraw.Draw(rim_glow),ImageDraw.Draw(rim_core)
    bg,bc=ImageDraw.Draw(beam_glow),ImageDraw.Draw(beam_core)

    # Moving glints on the EXISTING holographic arcs. No ellipse shape is moved.
    for j,(cx,cy,rx,ry,off) in enumerate(RINGS):
        angle=360*t + off
        draw_ellipse_arc(rg,cx,cy,rx,ry,angle,54,210,10)
        draw_ellipse_arc(rc,cx,cy,rx,ry,angle+12,25,245,5)

    # Upward-moving plasma packet in the existing central transmission column.
    # The emission is invisible at wrap, so the loop has no obvious jump.
    for shift in (0.0,0.5):
        p=(t+shift)%1.0
        strength=max(0.0,math.sin(math.pi*p))**0.65
        if strength < 0.08: continue
        y=63-56*p
        x=61.7
        q=int(255*strength)
        # long tapering trail below the bead, constrained to the central shaft
        for trailing in range(1,28):
            yy=y+trailing*0.57
            if yy > 65: break
            fade=(1-trailing/28)**1.65
            r=(1.4+2.3*fade)*S
            bg.ellipse(((x*S-r),(yy*S-r),(x*S+r),(yy*S+r)), fill=int(72*strength*fade))
            if trailing < 17:
                r=(0.42+0.6*fade)*S
                bc.ellipse((x*S-r,yy*S-r,x*S+r,yy*S+r),fill=int(105*strength*fade))
        # prominent moving head
        r=4.0*S
        bg.ellipse((x*S-r,y*S-r,x*S+r,y*S+r),fill=int(q*.85))
        r=1.7*S
        bc.ellipse((x*S-r,y*S-r,x*S+r,y*S+r), fill=q)

    # Small once-per-cycle flicker in the fixed console lamps (no geometry motion)
    status=Image.new('L',(W*S,H*S),0)
    sd=ImageDraw.Draw(status)
    for idx,(x,y) in enumerate([(18.5,54.5),(103.5,108.0)]):
        strength=0.5+0.5*math.sin(2*math.pi*(t*2+idx*0.5))
        r=1.35*S
        sd.ellipse((x*S-r,y*S-r,x*S+r,y*S+r),fill=int(155*strength))

    # Downsample effect layers (not the background), then add cyan luminosity.
    masks=[
        (rim_glow.filter(ImageFilter.GaussianBlur(9)),(10,116,231),0.56),
        (rim_core.filter(ImageFilter.GaussianBlur(1.5)),(68,220,255),0.87),
        (beam_glow.filter(ImageFilter.GaussianBlur(7)),(25,140,255),0.75),
        (beam_core.filter(ImageFilter.GaussianBlur(1.7)),(170,245,255),1.00),
        (status.filter(ImageFilter.GaussianBlur(3)),(245,133,36),0.55),
    ]
    result=base_array.copy()
    for mask, color, weight in masks:
        mask=mask.resize((W,H),Image.Resampling.LANCZOS)
        m=np.asarray(mask, dtype=np.float32)/255*weight
        col=np.asarray(color,dtype=np.float32)
        # Soft, emissive screen blending: nearby pixels brighten, never repaint structure
        result += (255-result)*(m[:,:,None]*col[None,None,:]/255)
    # Force fixed exact baseline outside any effect mask
    frames_rgb.append(Image.fromarray(np.uint8(np.clip(result+.5,0,255)),'RGB'))

# Fixed GIF palette for every frame: background exactly identical, no color-map flicker.
quant=base.quantize(colors=205, method=Image.Quantize.MEDIANCUT)
base_palette=quant.getpalette()[:205*3]
color_entries=[]
for j in range(51):
    u=j/50
    color_entries.extend((int(4+235*u),int(25+225*u),int(80+175*u)))
color_entries=color_entries[:51*3]
palette=(base_palette+color_entries)[:768]
palette+= [0]*(768-len(palette))
palette_image=Image.new('P',(1,1));palette_image.putpalette(palette)
fr_p=[f.quantize(palette=palette_image,dither=Image.Dither.NONE) for f in frames_rgb]

gif_path=OUT/'sensor_tech_135.gif'
fr_p[0].save(gif_path,save_all=True,append_images=fr_p[1:],duration=FRAME_MS,loop=0,disposal=2,optimize=False)

# Side-by-side key phases - quick visual confirmation even in viewers that don't play GIFs.
contact=Image.new('RGB',(4*240,2*255),'#101622')
cd=ImageDraw.Draw(contact)
for tile,k in enumerate([0,6,12,18,24,30,36,42]):
    frame=frames_rgb[k].resize((240,240),Image.Resampling.NEAREST)
    x=tile%4*240; y=tile//4*255
    contact.paste(frame,(x,y+15))
    cd.text((x+7,y+2),f'Frame {k+1:02}',fill='#e1ebfb')
contact.save(OUT/'animation_frames.png')

# Bigger GIF for easy inspection; this intentionally enlarges the 120px output.
large=[p.resize((360,360),Image.Resampling.NEAREST) for p in fr_p]
large[0].save(OUT/'sensor_tech_135_preview.gif',save_all=True,append_images=large[1:],duration=FRAME_MS,loop=0,disposal=2,optimize=True)

# Assert: palette indices outside highlighted regions stay identical across all frames.
all_a=np.stack([np.asarray(f) for f in fr_p],axis=0)
diff=np.any(all_a!=all_a[0:1],axis=0)
changed=int(np.count_nonzero(diff))
print('Created',gif_path,'frames=',len(fr_p),'loop_ms=',NFRAMES*FRAME_MS,'changed_pixel_positions=',changed,'of',W*H)
print('Unique frames=',len(set(p.tobytes() for p in fr_p)))
print('GIF size=',gif_path.stat().st_size)
